Por defecto el sitio se inicia en http://127.0.0.1:8000/

Dentro del mismo se encuentra la Nav var, que contiene las paginas, mediantes las cuales se puede agregar 
datos a los modelos (Vehiculo, Cliente y Empleado). Tambien van a encontrar una pagina para realizar una busqueda. 

Agregar datos al modelo y la busqueda se realiza mediante funciones, que se pueden ver en las views de GESTION.
Una vez agregado un cliente, empleado o vehiculo se redirige al inicio que proximamente contendra los vehiculos listados. 




Se utiliza la herencia HTML y lo solicitado en la consigna. 


SUPERUSER == [
    usuario: Admin
    Password: 123
]