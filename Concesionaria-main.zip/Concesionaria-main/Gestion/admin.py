from django.contrib import admin
from .models import Cliente,Empleado,Vehiculo

admin.site.register(Cliente)
admin.site.register(Empleado)
admin.site.register(Vehiculo)
