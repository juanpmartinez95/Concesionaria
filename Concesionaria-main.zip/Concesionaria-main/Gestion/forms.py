from  django import forms

class Buscar_empleadoform(forms.Form):
    nombre = forms.CharField()
   